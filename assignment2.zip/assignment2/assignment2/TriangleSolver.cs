﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace assignment2
{
    static public class TriangleSolver 
    {
    public static string Analyze(int N1, int N2, int N3)
    {
        if (((N1 + N2) > N3) && ((N1 + N3) > N2) && ((N2 + N3) > N1))
        {
            string str = "Triangle formed.";

            if (N1 == N2 && N2 == N3)
            {
                return string.Format("{0} Equilateral.", str);
            }
            else if (N1 == N2 || N2 == N3 || N1 == N3)
            {
                return string.Format("{0} Isosceles.", str);
            }
            else
            {
                return string.Format("{0} Scalene.", str);
            }
        }
        else
        {
            return "No triangle";
        }
    }
}
}

