﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace assignment2
{
    class assignment2
    {
        public static int ValidationOfMenu()
        {
            int choice = 0;
            string str = String.Empty;
            bool flag = false;
            do
            {
                Console.WriteLine("\nPlease Enter 1 to Enter Triangle Dimension");

                Console.WriteLine("Please Enter 2 to get Exit");

                Console.Write("\nWhat would you get to know? : ");

                str = Console.ReadLine();
                if (!int.TryParse(str, out choice))
                {
                    Console.WriteLine("Sorry! This is not valid Input");
                }
                else if (!((choice > 0) && (choice <= 2)))
                {
                    Console.WriteLine("Sorry! This is not valid Input");
                }
                else
                {
                    flag = true;
                }
            } while (flag == false);
            return choice;
        }



        public static int InputCheck(string tSide)
        {
            int no = 1;
            string str = String.Empty;
            bool flag = false;
            do
            {
                Console.Write("Enter {0} of Triangle(it should be >0) : ", tSide);
                str = Console.ReadLine();
                if (!int.TryParse(str, out no))
                {
                    Console.WriteLine("\nSorry! This is not valid Input");
                }
                else if (!(no > 0))
                {
                    Console.WriteLine("\nSorry! This is not valid Input");
                }
                else
                {
                    flag = true;
                }
            } while (flag == false);
            return no;
        }
        public static void Main(string[] arg)
        {
            int p = 5;
            do
            {
                switch (ValidationOfMenu())
                {
                    case 1:
                        int N1 = InputCheck("1st side");
                        int N2 = InputCheck("2nd side");
                        int N3 = InputCheck("3rd side");

                        Console.WriteLine(TriangleSolver.Analyze(N1, N2, N3));

                        break;
                    case 2:
                        p = 0;
                        Environment.Exit(0);
                        break;
                }
            } while (p == 5);
        }
    }

}
