﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using assignment2;
using NUnit.Framework;

namespace assignment2_testcase
{
    [TestFixture]
    public class Class1
    {
        //1st Testcase
        [Test]
        public void Analyze_input10_input10_input9_ExpectedOutput_Isosceles()
        {
            //Arrange
            int N1 = 10;
            int N2 = 10;
            int N3 = 9;

            string temp = String.Empty;
            if (((N1 + N2) > N3) && ((N1 + N3) > N2) && ((N2 + N3) > N1))
            {
                string str = "Triangle formed.";
                if (N1 == N2 && N2 == N3)
                {
                    temp = string.Format("{0} Equilateral.", str);
                }
                else if (N1 == N2 || N2 == N3 || N1 == N3)
                {
                    temp = string.Format("{0} Isosceles.", str);
                }
                else
                {
                    temp = string.Format("{0} Scalene.", str);
                }
            }
            else
            {
                temp = "No triangle";
            }

            //Act
            string op = TriangleSolver.Analyze(N1, N2, N3);

            //Assert
            Assert.AreEqual(op, temp);
        }


        //2nd Testcase
        [Test]
        public void Analyze_input100_input100_input100_ExpectedOutput_Equilateral()
        {
            //Arrange
            int N1 = 100;
            int N2 = 100;
            int N3 = 100;

            string temp = String.Empty;
            if (((N1 + N2) > N3) && ((N1 + N3) > N2) && ((N2 + N3) > N1))
            {
                string str = "Triangle formed.";
                if (N1 == N2 && N2 == N3)
                {
                    temp = string.Format("{0} Equilateral.", str);
                }
                else if (N1 == N2 || N2 == N3 || N1 == N3)
                {
                    temp = string.Format("{0} Isosceles.", str);
                }
                else
                {
                    temp = string.Format("{0} Scalene.", str);
                }
            }
            else
            {
                temp = "No triangle";
            }

            //Act
            string op = TriangleSolver.Analyze(N1, N2, N3);

            //Assert
            Assert.AreEqual(op, temp);
        }


        //3rd Testcase
        [Test]
        public void Analyze_input50_input60_input70_ExpectedOutput_Scalene()
        {
            //Arrange
            int N1 = 50;
            int N2 = 60;
            int N3 = 70;

            string temp = String.Empty;
            if (((N1 + N2) > N3) && ((N1 + N3) > N2) && ((N2 + N3) > N1))
            {
                string str = "Triangle formed.";
                if (N1 == N2 && N2 == N3)
                {
                    temp = string.Format("{0} Equilateral.", str);
                }
                else if (N1 == N2 || N2 == N3 || N1 == N3)
                {
                    temp = string.Format("{0} Isosceles.", str);
                }
                else
                {
                    temp = string.Format("{0} Scalene.", str);
                }
            }
            else
            {
                temp = "No triangle";
            }

            //Act
            string op = TriangleSolver.Analyze(N1, N2, N3);

            //Assert
            Assert.AreEqual(op, temp);
        }


        //4th Testcase
        [Test]
        public void Analyze_input5_input10_input15_ExpectedOutput_Notriangle()
        {
            //Arrange
            int N1 = 5;
            int N2 = 10;
            int N3 = 15;

            string temp = String.Empty;
            if (((N1 + N2) > N3) && ((N1 + N3) > N2) && ((N2 + N3) > N1))
            {
                string str = "Triangle formed.";
                if (N1 == N2 && N2 == N3)
                {
                    temp = string.Format("{0} Equilateral.", str);
                }
                else if (N1 == N2 || N2 == N3 || N1 == N3)
                {
                    temp = string.Format("{0} Isosceles.", str);
                }
                else
                {
                    temp = string.Format("{0} Scalene.", str);
                }
            }
            else
            {
                temp = "No triangle";
            }

            //Act
            string op = TriangleSolver.Analyze(N1, N2, N3);

            //Assert
            Assert.AreEqual(op, temp);
        }


        //5th Testcase
        [Test]
        public void Analyze_input25_input24_input48_ExpectedOutput_Scalene()
        {
            //Arrange
            int N1 = 25;
            int N2 = 24;
            int N3 = 48;

            string temp = String.Empty;
            if (((N1 + N2) > N3) && ((N1 + N3) > N2) && ((N2 + N3) > N1))
            {
                string str = "Triangle formed.";
                if (N1 == N2 && N2 == N3)
                {
                    temp = string.Format("{0} Equilateral.", str);
                }
                else if (N1 == N2 || N2 == N3 || N1 == N3)
                {
                    temp = string.Format("{0} Isosceles.", str);
                }
                else
                {
                    temp = string.Format("{0} Scalene.", str);
                }
            }
            else
            {
                temp = "No triangle";
            }

            //Act
            string op = TriangleSolver.Analyze(N1, N2, N3);

            //Assert
            Assert.AreEqual(op, temp);
        }


        //6th Testcase
        [Test]
        public void Analyze_input20_input20_input50_ExpectedOutput_Notriangle()
        {
            //Arrange
            int N1 = 20;
            int N2 = 20;
            int N3 = 50;

            string temp = String.Empty;
            if (((N1 + N2) > N3) && ((N1 + N3) > N2) && ((N2 + N3) > N1))
            {
                string str = "Triangle formed.";
                if (N1 == N2 && N2 == N3)
                {
                    temp = string.Format("{0} Equilateral.", str);
                }
                else if (N1 == N2 || N2 == N3 || N1 == N3)
                {
                    temp = string.Format("{0} Isosceles.", str);
                }
                else
                {
                    temp = string.Format("{0} Scalene.", str);
                }
            }
            else
            {
                temp = "No triangle";
            }

            //Act
            string op = TriangleSolver.Analyze(N1, N2, N3);

            //Assert
            Assert.AreEqual(op, temp);
        }


        //7th Testcase
        [Test]
        public void Analyze_input1_input1_input1_ExpectedOutput_Equilateral()
        {
            //Arrange
            int N1 = 1;
            int N2 = 1;
            int N3 = 1;

            string temp = String.Empty;
            if (((N1 + N2) > N3) && ((N1 + N3) > N2) && ((N2 + N3) > N1))
            {
                string str = "Triangle formed.";
                if (N1 == N2 && N2 == N3)
                {
                    temp = string.Format("{0} Equilateral.", str);
                }
                else if (N1 == N2 || N2 == N3 || N1 == N3)
                {
                    temp = string.Format("{0} Isosceles.", str);
                }
                else
                {
                    temp = string.Format("{0} Scalene.", str);
                }
            }
            else
            {
                temp = "No triangle";
            }

            //Act
            string op = TriangleSolver.Analyze(N1, N2, N3);

            //Assert
            Assert.AreEqual(op, temp);
        }


        //8th Testcase
        [Test]
        public void Analyze_input8_input8_input1_ExpectedOutput_Isosceles()
        {
            //Arrange
            int N1 = 8;
            int N2 = 8;
            int N3 = 1;

            string temp = String.Empty;
            if (((N1 + N2) > N3) && ((N1 + N3) > N2) && ((N2 + N3) > N1))
            {
                string str = "Triangle formed.";
                if (N1 == N2 && N2 == N3)
                {
                    temp = string.Format("{0} Equilateral.", str);
                }
                else if (N1 == N2 || N2 == N3 || N1 == N3)
                {
                    temp = string.Format("{0} Isosceles.", str);
                }
                else
                {
                    temp = string.Format("{0} Scalene.", str);
                }
            }
            else
            {
                temp = "No triangle";
            }

            //Act
            string op = TriangleSolver.Analyze(N1, N2, N3);

            //Assert
            Assert.AreEqual(op, temp);
        }


    }
 }

